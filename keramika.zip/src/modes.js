export default {

	add_wall_mode: false,
	orbit_mode: false,
	selection_mode: false,
};
